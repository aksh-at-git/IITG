function [solutionGrid] = btcs(spaceStep, timeStep, spatialPoints, timePoints, forcingFunction, initialCondition, leftBoundaryCondition, rightBoundaryCondition)
    lambda = timeStep / spaceStep^2;
    
    solutionGrid = zeros(timePoints + 1, spatialPoints + 1);

    % Initial and boundary conditions
    solutionGrid(1, :) = initialCondition((0:spatialPoints) * spaceStep);
    solutionGrid(:, 1) = leftBoundaryCondition((0:timePoints) * timeStep);
    solutionGrid(:, end) = rightBoundaryCondition((0:timePoints) * timeStep);

    % Loop through time
    for timeIndex = 2:timePoints + 1
        A = zeros(spatialPoints + 1, spatialPoints + 1);
        b = zeros(spatialPoints + 1, 1);

        % Diagonal elements
        A(2:spatialPoints, 2:spatialPoints) = diag(1 + 2 * lambda * ones(spatialPoints - 1, 1));

        % Upper and lower diagonal elements
        A(2:spatialPoints, 1:spatialPoints-1) = A(2:spatialPoints, 1:spatialPoints-1) - lambda * eye(spatialPoints - 1);
        A(2:spatialPoints, 3:spatialPoints+1) = A(2:spatialPoints, 3:spatialPoints+1) - lambda * eye(spatialPoints - 1);

        % Boundary condition adjustments
        A(1, 1) = 1;
        A(1, 2) = 0;
        A(end, end) = 1;
        A(end, end-1) = 0;

        b(2:spatialPoints) = solutionGrid(timeIndex-1, 2:spatialPoints) + timeStep * forcingFunction((1:spatialPoints-1) * spaceStep, (timeIndex-1) * timeStep);
        b(1) = solutionGrid(timeIndex, 1);
        b(end) = solutionGrid(timeIndex, end);

        solutionGrid(timeIndex, :) = (A\b)';
    end
end
