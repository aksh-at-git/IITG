function main
    spaceSteps = [1e-2, 1e-3, 1e-4];
    timeSteps = [5e-4, 1e-3, 1e-2];

    plotIndex = 0;
    for spaceStep = spaceSteps
        for timeStep = timeSteps
            timePoints = 1 / timeStep;
            spatialPoints = 1 / spaceStep;
            spatialDomain = (0:spatialPoints) * spaceStep;
            temporalDomain = (0:timePoints) * timeStep;

            u_ftcs = ftcs(spaceStep, timeStep, spatialPoints, timePoints, @rhs, @initial, @boundary1, @boundary2);

            actualSolution = exp(-(pi^2)) * sin(pi .* spatialDomain); % At t=1

            u_btcs = btcs(spaceStep, timeStep, spatialPoints, timePoints, @rhs, @initial, @boundary1, @boundary2);
            u_cn = crank_nicolson(spaceStep, timeStep, spatialPoints, timePoints, @rhs, @initial, @boundary1, @boundary2);

            % Plot and save the FTCS solution
            plotSolution(spatialDomain, u_ftcs, actualSolution, 'FTCS', spaceStep, timeStep, plotIndex);
            % surfacePlot(spatialDomain, temporalDomain, u_ftcs, 'FTCS', spaceStep, timeStep, plotIndex);

            % Plot and save the BTCS solution
            plotSolution(spatialDomain, u_btcs, actualSolution, 'BTCS', spaceStep, timeStep, plotIndex);
            surfacePlot(spatialDomain, temporalDomain, u_btcs, 'BTCS', spaceStep, timeStep, plotIndex);

            % Plot and save the Crank Nicolson solution
            plotSolution(spatialDomain, u_cn, actualSolution, 'Crank Nicolson', spaceStep, timeStep, plotIndex);
            surfacePlot(spatialDomain, temporalDomain, u_cn, 'Crank Nicolson', spaceStep, timeStep, plotIndex);

            plotIndex = plotIndex + 1;
        end
    end
end

function plotSolution(spatialDomain, numericalSolution, actualSolution, methodName, spaceStep, timeStep, index)
    fig = figure('Visible', 'off');
    plot(spatialDomain, numericalSolution(end, :), spatialDomain, actualSolution, '-*r');
    legend(methodName, 'Actual Solution');
    title(['h = ' + string(spaceStep) + ' k = ' + string(timeStep) + ' ' + methodName]);
    saveas(gcf, [methodName, num2str(index), '.png']);
    close(fig);
end

function [y] = rhs(~, ~)
    y = 0;
end

function [y] = initial(x)
    y = sin(pi * x);
end

function [y] = boundary1(~)
    y = 0;
end

function [y] = boundary2(~)
    y = 0;
end

function surfacePlot(x, y, data, methodName, h, k, id)
    fig = figure('Visible', 'off');
    surf(x, y, data);
    xlabel('Spatial Domain');
    ylabel('Temporal Domain');
    zlabel('Solution Value');
    title('h = ' + string(h) + ', k = ' + string(k) + ' (' + methodName + ')');
    shading interp;
    colorbar;
    saveas(fig, [methodName, '_surface_', num2str(id), '.png']);
    close(fig);
end
