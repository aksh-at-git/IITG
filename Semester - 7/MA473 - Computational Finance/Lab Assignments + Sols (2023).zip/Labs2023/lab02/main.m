id = 0; % Image ID for unique naming

k = 0.045; % Time step size
h = 0.2; % Spatial step size
sigma = 0.3;
T = 1;
r = 0.06;
lambda = (k / h) * h; % Calculation of lambda
disp(lambda);
tmax = T * sigma^2 / 2;
xmax = 5;
xmin = -5;
n = nearest(tmax / k); % Number of time points
disp(n);
m = (xmax - xmin) / h; % Number of spatial points

% Parameters for the functions
params = struct('sigma', sigma, 'r', r, 'delta', 0);

% Spatial and temporal domains
temporalDomain = (0:n) * k;
spatialDomain = (xmin:h:xmax) - xmin;

% Solve using various numerical schemes
solutionFTCS = FTCS(h, k, m, n, @fun, @f, @g1, @g2, xmin, params);
solutionBTCS = BTCS(h, k, m, n, @fun, @f, @g1, @g2, xmin, params);
solutionCN = CN(h, k, m, n, @fun, @f, @g1, @g2, xmin, params);

% Generate plots and surfaces for FTCS
generateVisuals('FTCS', spatialDomain, temporalDomain, solutionFTCS, h, k, id);
id = id + 1;

% Generate plots and surfaces for BTCS
generateVisuals('BTCS', spatialDomain, temporalDomain, solutionBTCS, h, k, id);
id = id + 1;

% Generate plots and surfaces for Crank-Nicolson
generateVisuals('Crank-Nicolson', spatialDomain, temporalDomain, solutionCN, h, k, id);
id = id + 1;

function val = fun(~, ~)
    val = 0;
end

function val = f(x, params)
    q_delta = 2 * (params.r - params.delta) / params.sigma^2;
    val = max(exp(x * (q_delta + 1) / 2) - exp(x * (q_delta - 1) / 2), 0);
end

function val = g1(~, ~)
    val = 0;
end

function val = g2(x, t, params)
    q_delta = 2 * (params.r - params.delta) / params.sigma^2;
    val = exp((q_delta + 1) * x / 2 + 0.25 * t * (q_delta + 1)^2);
end

function generateVisuals(methodName, spatialDomain, temporalDomain, solution, h, k, id)
    generatePlot(spatialDomain, solution(end, :), methodName, h, k, id);
    generateSurface(spatialDomain, temporalDomain, solution, methodName, h, k, id);
end

function generatePlot(spatialDomain, numericalSolution, methodName, spaceStep, timeStep, index)
    fig = figure('Visible', 'off');
    plot(spatialDomain, numericalSolution(end, :));
    legend(methodName);
    title(['h = ' + string(spaceStep) + ' k = ' + string(timeStep) + ' ' + methodName]);
    saveas(gcf, [methodName, num2str(index), '.png']);
    close(fig);
end

function generateSurface(x, y, data, methodName, h, k, id)
    fig = figure('Visible', 'off');
    surf(x, y, data);
    xlabel('Spatial Domain');
    ylabel('Temporal Domain');
    zlabel('Solution Value');
    title('h = ' + string(h) + ', k = ' + string(k) + ' (' + methodName + ')');
    shading interp;
    colorbar;
    saveas(fig, [methodName, '_surface_', num2str(id), '.png']);
    close(fig);
end
