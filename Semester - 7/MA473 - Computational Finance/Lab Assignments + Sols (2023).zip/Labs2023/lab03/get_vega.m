function vega = get_vega(N, M, x, t, lambda, dx, dt, K, T, r, sigma, delta, f1, f2, g, a, b, c, d, m, idx)
    
schemes = { @(N, M, x, t, lambda, dx, dt, K, T, r, sigma, delta, f1, f2, g, b, c, d) FTCS(N, M, x, t, lambda, dx, dt, K, T, r, sigma, delta, f1, f2, g, b, c, d),
            @(N, M, x, t, lambda, dx, dt, K, T, r, sigma, delta, f1, f2, g, b, c, d) BTCS(N, M, x, t, lambda, dx, dt, K, T, r, sigma, delta, f1, f2, g, b, c, d),
            @(N, M, x, t, lambda, dx, dt, K, T, r, sigma, delta, f1, f2, g, b, c, d) CN(N, M, x, t, lambda, dx, dt, K, T, r, sigma, delta, f1, f2, g, b, c, d)};

    del_sigma = 0.01;
    
    U_plus = schemes{idx}(N, M, x, flip(t), lambda, dx, -dt, K, T, r, sigma+del_sigma, delta, f1, f2, g, b, c, d);
    U_minus = schemes{idx}(N, M, x, flip(t), lambda, dx, -dt, K, T, r, sigma-del_sigma, delta, f1, f2, g, b, c, d);
    
    [~, m] = size(U_plus); 
    vega = zeros(1, m-2); 
    
    for i = 2:m-1 
        vega(1, i-1) = (U_plus(end, i) - U_minus(end, i))/ (2*del_sigma); 
    end
    
end
